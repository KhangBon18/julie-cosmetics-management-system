# Patch Plan — Prioritized Action Items

## Priority System
- 🔴 **P0 — Must fix before any deployment** (financial integrity, data corruption)
- 🟠 **P1 — Must fix before production** (security, feature completeness)
- 🟡 **P2 — Should fix** (UX gaps, code quality)
- 🔵 **P3 — Nice to have** (polish, optimization)

---

## Phase 1: Financial Integrity (P0) — Estimated 1 day

### Patch 1.1: Invoice soft-cancel instead of hard delete
**Files to modify:**
- `server/src/models/invoiceModel.js` — Replace `delete()` method
- `server/src/controllers/invoiceController.js` — Rename method
- `server/src/routes/invoiceRoutes.js` — Change route handler

**Exact change:**
```javascript
// invoiceModel.js — REPLACE delete() with:
cancel: async (id) => {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    // Check invoice exists and is not already cancelled
    const [inv] = await connection.query(
      'SELECT status FROM invoices WHERE invoice_id = ?', [id]
    );
    if (!inv[0]) throw Object.assign(new Error('Hóa đơn không tồn tại'), { status: 404 });
    if (inv[0].status === 'cancelled') throw Object.assign(new Error('Hóa đơn đã bị hủy'), { status: 400 });
    
    // Get items to restore stock via app logic (not triggers)
    const [items] = await connection.query(
      'SELECT product_id, quantity, unit_price FROM invoice_items WHERE invoice_id = ?', [id]
    );
    
    // Restore stock manually
    for (const item of items) {
      await connection.query(
        'UPDATE products SET stock_quantity = stock_quantity + ? WHERE product_id = ?',
        [item.quantity, item.product_id]
      );
      await logInventoryMovement(connection, {
        productId: item.product_id,
        movementType: 'cancellation',
        quantity: item.quantity,
        referenceType: 'invoice',
        referenceId: id,
        unitCost: item.unit_price,
        createdBy: null
      });
    }
    
    // Rollback CRM points and total_spent
    await connection.query(
      `UPDATE customers c SET 
        c.total_points = c.total_points - (SELECT points_earned FROM invoices WHERE invoice_id = ?),
        c.total_spent = c.total_spent - (SELECT final_total FROM invoices WHERE invoice_id = ?)
       WHERE c.customer_id = (SELECT customer_id FROM invoices WHERE invoice_id = ?)`,
      [id, id, id]
    );
    
    await connection.query(
      'UPDATE invoices SET status = "cancelled" WHERE invoice_id = ?', [id]
    );
    
    await connection.commit();
    return true;
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}
```

### Patch 1.2: Server-side price validation for admin POS
**Files to modify:**
- `server/src/models/invoiceModel.js` — Add price lookup in create()

**Exact change in `create()` method, between line 95 and 98:**
```javascript
// After stock validation loop, BEFORE subtotal calculation:
// Enforce server-side pricing — NEVER trust client unit_price
for (const item of items) {
  const [priceRows] = await connection.query(
    'SELECT sell_price FROM products WHERE product_id = ?',
    [item.product_id]
  );
  item.unit_price = parseFloat(priceRows[0].sell_price);
}
```

---

## Phase 2: CRM Integrity (P0) — Estimated 0.5 day

### Patch 2.1: Link customer_id in shop checkout
**Files to modify:**
- `server/src/routes/publicRoutes.js` — Line 178 checkout handler
- `client/src/components/shop/CheckoutPage.jsx` — Optional: send customer_id

**Exact change in publicRoutes.js:**
```javascript
// BEFORE line 178, add customer resolution:
let customerIdForInvoice = null;

// Check if request has auth token → extract customer_id
const authHeader = req.headers.authorization;
if (authHeader && authHeader.startsWith('Bearer')) {
  try {
    const jwt = require('jsonwebtoken');
    const decoded = jwt.verify(authHeader.split(' ')[1], process.env.JWT_SECRET);
    if (decoded.type === 'customer') {
      customerIdForInvoice = decoded.id;
    }
  } catch {} // Anonymous checkout is fine
}

// Use resolved customer_id
const invoiceId = await Invoice.create({
  customer_id: customerIdForInvoice,  // ← was hardcoded null
  ...
});
```

---

## Phase 3: Error Handling (P1) — Estimated 0.5 day

### Patch 3.1: Standardize error handling across all controllers
**Files to modify:**
- `server/src/controllers/roleController.js` — 7 catch blocks
- `server/src/controllers/notificationController.js` — 3 catch blocks
- `server/src/controllers/promotionController.js` — 5 catch blocks
- `server/src/controllers/settingController.js` — 4 catch blocks

**Pattern change (apply to all 19 instances):**
```javascript
// BEFORE:
} catch (error) {
  res.status(500).json({ message: 'Lỗi khi...', error: error.message });
}

// AFTER:
} catch (error) {
  next(error);
}
```

---

## Phase 4: Admin UI Completion (P1) — Estimated 2 days

### Patch 4.1: Add sidebar navigation for missing modules
**File:** `client/src/components/layout/Sidebar.jsx`
```javascript
// Add to navSections' "Bán hàng" section:
{ path: '/admin/returns', icon: FiRotateCcw, label: 'Đổi/Trả', roles: ['admin', 'manager'] },

// Add to "Hệ thống" section:
{ path: '/admin/promotions', icon: FiPercent, label: 'Khuyến mãi', roles: ['admin', 'manager'] },
{ path: '/admin/settings', icon: FiSettings, label: 'Cấu hình', roles: ['admin'] },
```

### Patch 4.2: Create missing admin pages
**New files to create:**
- `client/src/pages/ReturnsPage.jsx` — Returns management with approve/reject/complete workflow
- `client/src/pages/PromotionsPage.jsx` — CRUD for promotions
- `client/src/pages/SettingsPage.jsx` — CRM settings, store info

### Patch 4.3: Add routes in App.jsx
```jsx
const ReturnsPage = lazy(() => import('./pages/ReturnsPage'));
const PromotionsPage = lazy(() => import('./pages/PromotionsPage'));
const SettingsPage = lazy(() => import('./pages/SettingsPage'));

// In admin routes:
<Route path="returns" element={<R roles={['admin','manager']}><ReturnsPage /></R>} />
<Route path="promotions" element={<R roles={['admin','manager']}><PromotionsPage /></R>} />
<Route path="settings" element={<R roles={['admin']}><SettingsPage /></R>} />
```

---

## Phase 5: Shop Completion (P1) — Estimated 1-2 days

### Patch 5.1: Add coupon code to CheckoutPage
**File:** `client/src/components/shop/CheckoutPage.jsx`
- Add input field for coupon code
- Add `publicService.validatePromotion(code)` call
- Pass `promotion_code` in checkout payload

### Patch 5.2: Create "My Orders" page
**New files:**
- `client/src/components/shop/MyOrdersPage.jsx`
- Backend: Add `GET /api/customer-auth/orders` endpoint querying invoices by customer_id

---

## Phase 6: Business Logic Fixes (P1-P2) — Estimated 1 day

### Patch 6.1: Leave date overlap check
**Files:** `leaveController.js`, `staffController.js`
```sql
SELECT COUNT(*) as overlap 
FROM leave_requests 
WHERE employee_id = ? AND status IN('pending','approved') 
  AND start_date <= ? AND end_date >= ?
```

### Patch 6.2: Auto-calculate total_days in admin leave create
**File:** `leaveController.js:25-29`
```javascript
create: async (req, res, next) => {
  try {
    const { employee_id, leave_type, start_date, end_date, reason } = req.body;
    const start = new Date(start_date);
    const end = new Date(end_date);
    const total_days = Math.ceil(Math.abs(end - start) / (1000 * 60 * 60 * 24)) + 1;
    const id = await Leave.create({ employee_id, leave_type, start_date, end_date, total_days, reason });
    res.status(201).json({ message: 'Tạo đơn nghỉ phép thành công', leave: await Leave.findById(id) });
  } catch (error) { next(error); }
}
```

### Patch 6.3: Fix FE points display
**File:** `InvoicesPage.jsx:100`
```javascript
// BEFORE:
const pointsEarned = Math.floor(finalTotal / 10000);

// AFTER — remove FE calculation, show server response:
// Remove pointsEarned display during invoice creation preview
// OR fetch settings from server: const settings = await settingService.getAll();
// pointsEarned = Math.floor(finalTotal / 1000) * (settings['crm.points_per_1000'] || 1);
```

### Patch 6.4: Return item validation
**File:** `server/src/models/returnModel.js:50`
```javascript
// Before inserting return items, verify each item was in the original invoice:
for (const item of items) {
  const [inv_items] = await connection.query(
    'SELECT quantity FROM invoice_items WHERE invoice_id = ? AND product_id = ?',
    [invoice_id, item.product_id]
  );
  if (!inv_items.length) {
    throw Object.assign(new Error(`Sản phẩm ID ${item.product_id} không nằm trong hóa đơn gốc`), { status: 400 });
  }
  if (item.quantity > inv_items[0].quantity) {
    throw Object.assign(new Error(`Số lượng trả vượt quá số lượng đã mua`), { status: 400 });
  }
}
```

---

## Phase 7: Polish (P2-P3) — Estimated 1-2 days

| # | Task | Priority | Effort |
|---|------|----------|--------|
| 7.1 | Add `logAudit()` calls in invoice, import, employee controllers | P2 | 2h |
| 7.2 | Wire notification triggers (invoice → manager, leave approval → staff) | P2 | 3h |
| 7.3 | FE logout calls `/auth/logout` with refresh token | P2 | 30m |
| 7.4 | Fix profit report to use COGS instead of import cost | P2 | 1h |
| 7.5 | Add graceful shutdown in server.js | P3 | 30m |
| 7.6 | Add validation middleware for brands, categories, suppliers, reviews | P3 | 1h |
| 7.7 | Migrate uploads to cloud storage | P3 | 3h |

---

## Timeline Summary

| Phase | Scope | Effort | Dependency |
|-------|-------|--------|------------|
| 1 | Financial Integrity | 1 day | None |
| 2 | CRM Integrity | 0.5 day | None |
| 3 | Error Handling | 0.5 day | None |
| 4 | Admin UI Completion | 2 days | Phase 3 |
| 5 | Shop Completion | 1-2 days | Phase 2 |
| 6 | Business Logic | 1 day | None |
| 7 | Polish | 1-2 days | Phase 1-6 |
| **Total** | **All** | **6-8 dev-days** | |

# UI/UX Flow Review

## Flow 1: Admin Login → Dashboard
**Status: Completed** [CONFIRMED]
- Login form at `/admin/login` (`LoginPage.jsx`)
- Auth via `authController.login()` with throttling (5 attempts/15min) and audit log
- Redirect to `/admin` → `HomePage.jsx` dashboard
- **UX**: Clean. Toastify notifications on error.
- **Missing**: No "forgot password" link. No MFA.

## Flow 2: Dashboard
**Status: Completed** [CONFIRMED]
- `HomePage.jsx` (12.5KB) — Revenue charts (Recharts), top products, customer stats, low stock alerts
- Data fetched from multiple endpoints on mount
- **Missing**: No real-time updates. Static on load. No auto-refresh interval.

## Flow 3: Product Management
**Status: Completed** [CONFIRMED]
- `ProductsPage.jsx` — Full CRUD with server-side pagination, search, category/brand filter, sort
- Image upload via multer
- Soft delete (updates `deleted_at`, sets `is_active=0`)
- **Enterprise Gap**: No bulk operations. No product variants. No CSV import.

## Flow 4: Inventory / Import
**Status: Completed** [CONFIRMED]
- `ImportsPage.jsx` — Create import receipt with supplier, items, quantities
- Backend uses transaction + inventory movement logging
- DB trigger auto-updates stock
- **Missing**: No import cancellation/void. Delete is hard delete. No purchase order workflow.

## Flow 5: Invoices / POS
**Status: Partial** [CONFIRMED]
- `InvoicesPage.jsx` — Create invoice (POS), view list, view detail
- Product search, customer selection, auto-discount display
- **CRITICAL BUG**: unit_price sent from client, not verified server-side
- **CRITICAL BUG**: Delete is hard delete on financial record
- **Missing**: No invoice edit. No "cancel" status change. No invoice print/PDF.

## Flow 6: Employees / Leaves / Salaries
**Status: Completed** [CONFIRMED]
- `EmployeesPage.jsx` — CRUD, position assignment
- `LeavesPage.jsx` — List with approve/reject actions (manager+)
- `SalariesPage.jsx` — Generate payroll by month/year, view, edit bonus/deductions
- Staff portal at `/staff/*` — Personal dashboard, profile (restricted fields), leave request, salary history
- **Bug**: Leave overlap not checked. Admin leave create trusts client total_days.

## Flow 7: Roles / Permissions
**Status: Broken** [CONFIRMED]
- Backend has `roleRoutes.js` with full CRUD for roles and permissions
- Frontend has **NO page** for managing roles/permissions
- Sidebar has **NO nav item** for roles
- Middleware does **NOT check** permission tables — uses hardcoded enum roles
- This entire module is dead from user perspective.

## Flow 8: Storefront (Shop)
**Status: Completed** [CONFIRMED]
- `StorefrontHome.jsx` — Hero section, featured products (by sales), new arrivals, skeleton loading
- `ShopPage.jsx` — Product grid, category/brand/price filter, search, pagination
- `ProductDetailPage.jsx` — Gallery images, reviews, related products, add-to-cart
- **Good**: Responsive design. Loading skeletons. Price formatting.

## Flow 9: Cart
**Status: Completed** [CONFIRMED]
- `CartPage.jsx` — Item list, quantity controls, subtotal, remove, clear
- State in `CartContext` with localStorage persistence
- **Missing**: No "save for later". Cart lost on device switch. No stock re-validation before checkout.

## Flow 10: Checkout
**Status: Partial** [CONFIRMED]
- `CheckoutPage.jsx` — Customer form (auto-fills from profile if logged in), payment method selection, order summary
- Login required (component-level check at line 98)
- FE validation (name, phone, email regex)
- **CRITICAL**: customer_id not passed to backend → no CRM linkage
- **Missing**: No coupon/promotion code input. No address book selection. Shipping fee hardcoded (500K threshold).

## Flow 11: Post-Checkout
**Status: Partial** [CONFIRMED]
- After submit, shows order confirmation with order ID, total, payment method
- `clearCart()` called on success
- **Missing**: No email confirmation. No order tracking page. No "my orders" for customer. Dead-end after this screen.

## Flow 12: Reviews
**Status: Completed** [CONFIRMED]
- Public reviews shown on product detail page
- Admin can toggle visibility in `ReviewsPage.jsx`
- **Bug**: No purchase verification. Anonymous spam possible.

## Flow 13: Notifications
**Status: Broken** [CONFIRMED]
- No FE page. No bell icon. No sidebar nav.
- Backend endpoints exist but `Notification.create()` is never called anywhere.
- User will always see zero notifications.

## Flow 14: Settings
**Status: Backend Only** [CONFIRMED]
- `settingsCache.js` works correctly — fetches from DB, caches 5 min, invalidates on update
- Used by `invoiceModel.create()` for CRM discount/points values
- **Missing**: No admin UI to view/edit settings. Must modify DB directly.

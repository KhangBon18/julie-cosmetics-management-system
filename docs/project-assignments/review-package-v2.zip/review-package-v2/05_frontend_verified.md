# Frontend Verified

## Page Inventory [CONFIRMED]

### Admin Pages (14 pages, all lazy-loaded)
| Page | File | Route | Role Guard | Server Pagination | Search/Filter |
|------|------|-------|------------|-------------------|---------------|
| Dashboard | `HomePage.jsx` (12.5KB) | `/admin` | Any auth | N/A | N/A |
| Products | `ProductsPage.jsx` (12.1KB) | `/admin/products` | Any auth | ✅ Backend | ✅ search, category, brand, sort |
| Invoices | `InvoicesPage.jsx` (16.7KB) | `/admin/invoices` | Any auth | ✅ Backend | ✅ customer, payment |
| Customers | `CustomersPage.jsx` (7.2KB) | `/admin/customers` | Any auth | ✅ Backend | ✅ search, tier |
| Employees | `EmployeesPage.jsx` (7.4KB) | `/admin/employees` | admin, manager | ✅ Backend | ✅ |
| Salaries | `SalariesPage.jsx` (8KB) | `/admin/salaries` | admin, manager | ✅ Backend | ✅ month, year |
| Imports | `ImportsPage.jsx` (11.7KB) | `/admin/imports` | admin, manager, warehouse | ✅ Backend | ✅ supplier |
| Leaves | `LeavesPage.jsx` (2.8KB) | `/admin/leaves` | Any auth | ✅ Backend | ✅ status |
| Reviews | `ReviewsPage.jsx` (3KB) | `/admin/reviews` | admin, manager | ✅ Backend | — |
| Reports | `ReportsPage.jsx` (11.9KB) | `/admin/reports` | admin, manager | N/A | ✅ year |
| Users | `UsersPage.jsx` (4.7KB) | `/admin/users` | admin only | ✅ Backend | — |
| Brands | `BrandsPage.jsx` (1KB) | `/admin/brands` | admin, manager | ❌ Client-only via CrudPageFactory | — |
| Categories | `CategoriesPage.jsx` (0.7KB) | `/admin/categories` | admin, manager | ❌ Client-only | — |
| Positions | `PositionsPage.jsx` (0.9KB) | `/admin/positions` | admin, manager | ❌ Client-only | — |
| Suppliers | `SuppliersPage.jsx` (1KB) | `/admin/suppliers` | admin, manager, warehouse | ❌ Client-only | — |

### Staff Pages (4 pages)
| Page | File | Route |
|------|------|-------|
| Staff Dashboard | `staff/StaffDashboard.jsx` | `/staff` |
| My Profile | `staff/MyProfilePage.jsx` | `/staff/profile` |
| My Leaves | `staff/MyLeavePage.jsx` | `/staff/leaves` |
| My Salary | `staff/MySalaryPage.jsx` | `/staff/salaries` |

### Shop Pages (7 components in `components/shop/`)
| Page | File | Route |
|------|------|-------|
| Storefront Home | `StorefrontHome.jsx` (9.9KB) | `/shop` |
| Product Catalog | `ShopPage.jsx` (12.2KB) | `/shop/products` |
| Product Detail | `ProductDetailPage.jsx` (9.8KB) | `/shop/product/:id` |
| Cart | `CartPage.jsx` (4.8KB) | `/shop/cart` |
| Checkout | `CheckoutPage.jsx` (11.2KB) | `/shop/checkout` |
| Auth (Login/Register) | `ShopAuthPage.jsx` (7.7KB) | `/shop/auth` |
| Layout | `ShopLayout.jsx` (7.6KB) | Wrapper |

## Missing Pages (Backend API exists, no FE) [CONFIRMED]
1. **Returns Management** — `returnRoutes.js` has full CRUD. No admin page.
2. **Promotions Management** — `promotionRoutes.js` has full CRUD. No admin page.
3. **Notifications** — `notificationRoutes.js` has read/mark. No page or bell icon.
4. **Settings** — `settingRoutes.js` has admin CRUD. No settings page.
5. **Shipping Management** — `shippingRoutes.js` has status updates. No tracking page.
6. **Payment Management** — `paymentRoutes.js` has confirm/update. No payment dashboard.
7. **Audit Log Viewer** — `audit_logs` table written to. No admin viewer.
8. **My Orders (Customer)** — Customer can checkout but cannot view order history.

## State Management [CONFIRMED]
- `AuthContext.jsx` — Dual auth (staff + customer). Stores user object. `login()`, `customerLogin()`, `customerRegister()`, `logout()`. Token in localStorage.
- `CartContext.jsx` — Shop cart. localStorage persistence. `addToCart()`, `removeFromCart()`, `updateQuantity()`, `clearCart()`, `cartTotal` computed.

## Route Guards [CONFIRMED]
- `ProtectedRoute.jsx` — Checks `AuthContext.user` exists. If `allowedRoles` prop, checks `user.role` in array. Redirects to `/admin/login` if unauthorized.
- Applied in `App.jsx:88-99` for admin routes that need manager/admin/warehouse.
- Shop routes (`/shop/*`) have NO route guards — intentionally public.
- Checkout page (`CheckoutPage.jsx:98-113`) checks `if (!user)` and shows login prompt. This is a component-level guard, not route-level.

## Business Logic in Frontend (Problematic) [CONFIRMED]
1. **Discount calculation**: `InvoicesPage.jsx:59-64` — `getDiscount()` returns hardcoded 5% for gold, 2% for silver. Server uses dynamic `SettingsCache` values.
2. **Points calculation**: `InvoicesPage.jsx:100` — `Math.floor(finalTotal / 10000)`. Server uses `Math.floor(finalTotal / 1000) * pointsPer`.
3. **Shipping fee**: `CheckoutPage.jsx:39` — `cartTotal >= 500000 ? 0 : 30000`. Hardcoded. Not validated or used server-side.

## Code Quality [CONFIRMED]
- **ErrorBoundary**: `components/ErrorBoundary.jsx` wraps entire app. Catches render errors. Shows fallback UI.
- **Loading state**: `App.jsx:44-48` defines global `<Loading />` spinner for Suspense.
- **Toast notifications**: `react-toastify` used consistently across all pages for success/error feedback.
- **Empty states**: Most pages show "Chưa có dữ liệu" text when list is empty. Not visually rich but functional.

# Backend Verified

## Route Inventory [CONFIRMED]

25 route files in `server/src/routes/`. All mounted in `server.js:76-102`.

| Route File | Base Path | Auth | Role Guard | Validation | Controller |
|------------|-----------|------|------------|------------|------------|
| `authRoutes.js` | `/api/auth` | Rate limited | — | `validateLogin`, `validateChangePassword` | authController |
| `customerAuthRoutes.js` | `/api/customer-auth` | Rate limited | — | Inline validation | Inline (279 lines) |
| `publicRoutes.js` | `/api/public` | None | — | `validateCheckout` | Inline (279 lines) |
| `productRoutes.js` | `/api/products` | protect | managerUp for write | `validateProduct` | productController |
| `invoiceRoutes.js` | `/api/invoices` | protect | managerUp for delete | `validateInvoice` | invoiceController |
| `importRoutes.js` | `/api/imports` | protect | warehouse+ | `validateImport` | importController |
| `customerRoutes.js` | `/api/customers` | protect | managerUp for write | `validateCustomer` | customerController |
| `employeeRoutes.js` | `/api/employees` | protect | managerUp | `validateEmployee` | employeeController |
| `salaryRoutes.js` | `/api/salaries` | protect | managerUp | `validateSalaryGenerate` | salaryController |
| `leaveRoutes.js` | `/api/leaves` | protect | managerUp for approve | `validateLeave` | leaveController |
| `userRoutes.js` | `/api/users` | protect | adminOnly | `validateUserCreate` | userController |
| `brandRoutes.js` | `/api/brands` | protect | managerUp for write | — | brandController |
| `categoryRoutes.js` | `/api/categories` | protect | managerUp for write | — | categoryController |
| `positionRoutes.js` | `/api/positions` | protect | managerUp for write | — | positionController |
| `supplierRoutes.js` | `/api/suppliers` | protect | warehouse+ | — | supplierController |
| `reviewRoutes.js` | `/api/reviews` | protect | managerUp for toggle/delete | — | reviewController |
| `reportRoutes.js` | `/api/reports` | protect | managerUp | — | reportController |
| `staffRoutes.js` | `/api/staff` | protect | — | — | staffController |
| `roleRoutes.js` | `/api/roles` | protect | adminOnly | — | roleController |
| `settingRoutes.js` | `/api/settings` | protect | adminOnly | — | settingController |
| `promotionRoutes.js` | `/api/promotions` | protect | managerUp | — | promotionController |
| `notificationRoutes.js` | `/api/notifications` | protect | — | — | notificationController |
| `paymentRoutes.js` | `/api/payments` | protect | managerUp | — | paymentController |
| `shippingRoutes.js` | `/api/shipping` | protect | managerUp | — | shippingController |
| `returnRoutes.js` | `/api/returns` | protect | managerUp for approve | — | returnController |

## Validation Coverage [CONFIRMED]

`validationMiddleware.js` defines 10 validator sets:

| Validator | Applied To | Fields Checked |
|-----------|-----------|----------------|
| `validateInvoice` | POST /invoices | items[].product_id, quantity, unit_price, payment_method, customer_id |
| `validateImport` | POST /imports | supplier_id, items[] |
| `validateEmployee` | POST/PUT /employees | full_name, phone, gender, base_salary |
| `validateSalaryGenerate` | POST /salaries/generate | month (1-12), year (2000-2100) |
| `validateCustomer` | POST/PUT /customers | full_name, phone, gender, email |
| `validateProduct` | POST/PUT /products | product_name, brand_id, category_id, sell_price |
| `validateUserCreate` | POST /users | username (min 3), password (min 6), role |
| `validateLeave` | POST /leaves | leave_type, start_date, end_date, reason |
| `validateLogin` | POST /auth/login | username, password |
| `validateChangePassword` | PUT /auth/change-password | current_password, new_password (min 6) |

**Gap:** Brands, Categories, Positions, Suppliers, Reviews, Returns, Promotions, Settings, Shipping, Payments have NO validation middleware. [CONFIRMED]

## Transaction Discipline [CONFIRMED]

| Operation | Uses Transaction | Uses FOR UPDATE | Inventory Log |
|-----------|-----------------|-----------------|---------------|
| Invoice create | ✅ `invoiceModel.js:72` | ✅ `:83` | ✅ `:183-191` |
| Invoice delete | ✅ `invoiceModel.js:234` | ✗ | ✗ |
| Import create | ✅ `importModel.js:57` | ✗ | ✅ `:88-96` |
| Import delete | ✅ `importModel.js:117` | ✗ | ✗ |
| Return create | ✅ `returnModel.js:53` | ✗ | ✗ |
| Return complete | ✅ `returnModel.js:96` | ✗ | ✅ `:106-114` |

## Dead Routes (Backend exists, no FE) [CONFIRMED]
1. `/api/roles/*` — Full CRUD but no admin page, no sidebar nav
2. `/api/promotions/*` — Full CRUD but no admin page
3. `/api/notifications/*` — Read/mark endpoints, never triggered
4. `/api/settings/*` — Admin CRUD but no settings page
5. `/api/payments/*` — Status updates but no payment management page
6. `/api/shipping/*` — Status updates but no shipping tracking page
7. `/api/returns/*` — Full workflow but no returns management page

## Inconsistent Patterns [CONFIRMED]
1. **Error handling** — 13 controllers use `next(error)`. 4 controllers (`roleController`, `promotionController`, `settingController`, `notificationController`) bypass error middleware with `res.status(500).json({error: error.message})`.
2. **Fat routes vs controllers** — `publicRoutes.js` (279 lines) has inline business logic. `customerAuthRoutes.js` (5.6KB) also has inline logic. All other routes properly delegate to controllers.
3. **Audit logging** — Only `authController` and `returnController` call `logAudit()`. Invoice/import/employee CRUD operations have no audit trail despite the table existing.

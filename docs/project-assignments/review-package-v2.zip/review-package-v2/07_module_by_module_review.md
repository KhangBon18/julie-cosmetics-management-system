# Module-by-Module Review

## 1. Auth (Staff + Customer)
- **Maturity: 8/10** [CONFIRMED]
- **Strengths**: Access token 15m + refresh token 30d with DB hash. Login throttling (5/15min). Audit log on login/logout. Password change revokes all tokens. Dual auth (staff/customer) properly separated.
- **Weaknesses**: Token stored in localStorage (XSS risk). No forgot/reset password flow. FE logout only clears localStorage, doesn't call server `/auth/logout` to revoke refresh token.
- **Missing**: CSRF protection if moving to HttpOnly cookies. Email verification for customer registration.
- **Enterprise Fitness**: 6/10 — Needs HttpOnly cookies + CSRF + password reset.
- **Next Actions**: (1) Call `/auth/logout` from FE `logout()`. (2) Add forgot-password email flow. (3) Evaluate HttpOnly cookies vs localStorage trade-off.

## 2. Products
- **Maturity: 7.5/10** [CONFIRMED]
- **Strengths**: Server-side pagination, multi-filter (category+brand+search+price+sort), soft delete, FULLTEXT search, category hierarchy (parent includes children). Product update does NOT include stock_quantity (cleared from old report).
- **Weaknesses**: No product variants (color, size). No bulk import. Image stored locally.
- **Missing**: Product variants table. SKU field. Weight/dimensions.
- **Enterprise Fitness**: 5/10 — Needs variants and cloud storage.
- **Next Actions**: (1) Add cloud image storage. (2) Consider product variants if needed for cosmetics business.

## 3. Inventory / Imports
- **Maturity: 7.5/10** [CONFIRMED]
- **Strengths**: Transaction + inventory movement logging. Product validation before insert. Trigger ensures stock accuracy. Server-side pagination.
- **Weaknesses**: Import delete is hard delete. No import cancellation workflow. No purchase order → import receipt flow.
- **Missing**: Import cancel/void status. Minimum stock alerts (backend exists via `getLowStock()`, but no auto-notification trigger).
- **Enterprise Fitness**: 5/10 — Needs PO workflow and cancel flow.
- **Next Actions**: (1) Add import cancel (soft). (2) Wire low-stock notification trigger.

## 4. Invoices / POS
- **Maturity: 6/10** [CONFIRMED]
- **Strengths**: Transaction + FOR UPDATE lock on stock. Server-side discount from CRM tier + promotion. Promotion usage_count atomically incremented. Payment transaction created automatically.
- **Weaknesses**: **C1** Hard delete. **C2** Admin path trusts client unit_price. No update/cancel status flow despite column existing. No invoice PDF/print.
- **Missing**: Status workflow (draft→confirmed→paid→completed). Invoice editing. PDF generation.
- **Enterprise Fitness**: 3/10 — C1 and C2 are financial integrity failures.
- **Next Actions**: **(1) Fix C1 — soft cancel. (2) Fix C2 — server-side price lookup. (3) Add updateStatus route + controller method (model already has it at line 223).**

## 5. Returns / Refunds
- **Maturity: 6/10** [CONFIRMED]
- **Strengths**: State machine (requested→approved→completed/rejected). Inventory rollback on complete with movement logging. Audit log on create/approve/complete.
- **Weaknesses**: No frontend page. No sidebar nav. Items not validated against source invoice. No time limit on returns.
- **Missing**: Admin returns page. Return item validation. Return time limit setting.
- **Enterprise Fitness**: 3/10 — Feature exists in code but unreachable by users.
- **Next Actions**: (1) Create ReturnsPage.jsx. (2) Add to sidebar. (3) Validate items against invoice.

## 6. Reviews
- **Maturity: 6/10** [CONFIRMED]
- **Strengths**: Toggle visibility. UNIQUE constraint per customer+product. Public reviews with pagination.
- **Weaknesses**: No purchase verification. Anonymous (customer_id=NULL) can spam. No moderation queue.
- **Missing**: Purchase verification JOIN. Reply from admin. Rating analytics.
- **Enterprise Fitness**: 4/10 — Open to abuse without purchase check.
- **Next Actions**: (1) Add purchase verification. (2) Rate limit anonymous reviews.

## 7. Employees / HR
- **Maturity: 7.5/10** [CONFIRMED]
- **Strengths**: Position history tracking. Leave workflow (pending→approved→rejected). Salary auto-calculation with cross-month leave handling (`LEAST/GREATEST` overlap). UNIQUE(emp,month,year) prevents duplicate salary. Staff portal with restricted field updates.
- **Weaknesses**: Leave overlap not checked. Admin leave create trusts client total_days. Sick leave deduction rate not configurable.
- **Missing**: Attendance/timekeeping system. Leave balance tracking. Leave type quota per year.
- **Enterprise Fitness**: 6/10 — Solid for basic HR. Needs attendance system for real use.
- **Next Actions**: (1) Add leave date overlap check. (2) Auto-calculate total_days in admin route.

## 8. RBAC / Roles / Permissions
- **Maturity: 2/10** [CONFIRMED]
- **Strengths**: Database schema is proper (roles, permissions, role_permissions with module+action). Backend CRUD API works.
- **Weaknesses**: Middleware ignores RBAC tables entirely — uses hardcoded `roleCheck('admin','manager')`. No FE page. No sidebar entry.
- **Missing**: Everything functional. The "RBAC module" is dead schema + dead API.
- **Enterprise Fitness**: 0/10 — Non-functional.
- **Next Actions**: Either (a) wire middleware to use RBAC tables + build UI, or (b) remove tables and document enum-based approach as intentional.

## 9. Reports / Dashboard
- **Maturity: 7/10** [CONFIRMED]
- **Strengths**: Revenue by month/quarter. Profit report. Top products. Inventory stats. HR stats. CSV export (invoices, products, customers).
- **Weaknesses**: Profit calculation = Revenue - Import Cost per month (not COGS). No PDF export.
- **Missing**: COGS-based profit. Date range filters (not just year). Dashboard auto-refresh.
- **Enterprise Fitness**: 5/10 — Useful but accounting inaccuracy in profit report.
- **Next Actions**: (1) Fix profit to use COGS. (2) Add date range picker.

## 10. Shop / Public APIs
- **Maturity: 6/10** [CONFIRMED]
- **Strengths**: Product catalog with filters. Featured products by actual sales data. Related products. Public reviews. Checkout with server-side price validation. Shipping order auto-created. Skeleton loading.
- **Weaknesses**: **C3** customer_id always null. No coupon UI. No "my orders". Cart localStorage only.
- **Missing**: Order tracking page. Wishlist. Product comparison. Email confirmations.
- **Enterprise Fitness**: 4/10 — Shop works for browsing and basic purchase but post-purchase UX is empty.
- **Next Actions**: **(1) Fix C3. (2) Add coupon input. (3) Create order history page.**

## 11. Notifications
- **Maturity: 1/10** [CONFIRMED]
- **Strengths**: DB table + model + controller + routes exist.
- **Weaknesses**: `Notification.create()` is never called. No triggers. No FE page. Feature is 100% dead.
- **Missing**: Everything. This is scaffolding that was never wired.
- **Enterprise Fitness**: 0/10
- **Next Actions**: Wire triggers in key events (invoice create, leave approval, low stock).

## 12. Settings
- **Maturity: 5/10** [CONFIRMED]
- **Strengths**: `SettingsCache` is well-implemented (5min TTL, type casting, stale cache on error). CRM settings (discount %, points) are dynamic from DB.
- **Weaknesses**: No admin UI. Settings editable only via DB or API call.
- **Missing**: Settings admin page with categories.
- **Enterprise Fitness**: 4/10 — Backend solid, needs UI.
- **Next Actions**: Create SettingsPage.jsx. Add to sidebar under "Hệ thống".

## 13. Payment
- **Maturity: 3/10** [CONFIRMED]
- **Strengths**: `payment_transactions` auto-created on invoice create. Status(pending/confirmed) logic based on payment method.
- **Weaknesses**: No real payment gateway. No webhook handlers. No payment management UI.
- **Missing**: VNPay/MoMo/ZaloPay integration. QR code. Bank transfer confirmation.
- **Enterprise Fitness**: 2/10 — Placeholder.
- **Next Actions**: Low priority unless real payments needed. Otherwise, document as future work.

## 14. Shipping
- **Maturity: 3/10** [CONFIRMED]
- **Strengths**: Shipping order auto-created on checkout with address. Status machine exists in DB.
- **Weaknesses**: No tracking UI. No shipping partner API. No status update UI.
- **Missing**: Everything beyond creation.
- **Enterprise Fitness**: 2/10 — Write-only feature.
- **Next Actions**: Build admin shipping status page. Add customer tracking view.

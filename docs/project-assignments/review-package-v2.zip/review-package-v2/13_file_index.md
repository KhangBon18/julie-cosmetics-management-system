# File Index — Quick Reference

> Master reference for locating any component in the system.

## Server Files

### Routes (25 files)
| File | Path | Size | Purpose |
|------|------|------|---------|
| authRoutes.js | server/src/routes/ | 0.5KB | Staff login/logout/refresh/changePassword |
| customerAuthRoutes.js | server/src/routes/ | 5.6KB | Customer register/login/profile (INLINE LOGIC) |
| publicRoutes.js | server/src/routes/ | 10.7KB | Public shop API (INLINE LOGIC) |
| productRoutes.js | server/src/routes/ | 0.5KB | Product CRUD + low-stock |
| invoiceRoutes.js | server/src/routes/ | 0.6KB | Invoice CRUD + revenue stats |
| importRoutes.js | server/src/routes/ | 0.4KB | Import receipt CRUD |
| customerRoutes.js | server/src/routes/ | 0.5KB | Customer CRM CRUD |
| employeeRoutes.js | server/src/routes/ | 0.5KB | Employee management |
| leaveRoutes.js | server/src/routes/ | 0.5KB | Leave request CRUD |
| salaryRoutes.js | server/src/routes/ | 0.5KB | Salary CRUD + auto-generate |
| userRoutes.js | server/src/routes/ | 0.5KB | User account management |
| brandRoutes.js | server/src/routes/ | 0.4KB | Brand CRUD |
| categoryRoutes.js | server/src/routes/ | 0.4KB | Category CRUD (tree) |
| positionRoutes.js | server/src/routes/ | 0.4KB | Position CRUD |
| supplierRoutes.js | server/src/routes/ | 0.4KB | Supplier CRUD |
| reviewRoutes.js | server/src/routes/ | 0.4KB | Review CRUD + toggle |
| reportRoutes.js | server/src/routes/ | 0.6KB | Reports + CSV exports |
| staffRoutes.js | server/src/routes/ | 0.5KB | Staff self-service portal |
| roleRoutes.js | server/src/routes/ | 0.5KB | RBAC management (DEAD) |
| settingRoutes.js | server/src/routes/ | 0.4KB | Settings CRUD |
| promotionRoutes.js | server/src/routes/ | 0.5KB | Promotion CRUD |
| notificationRoutes.js | server/src/routes/ | 0.4KB | Notification read/mark |
| paymentRoutes.js | server/src/routes/ | 0.4KB | Payment status management |
| shippingRoutes.js | server/src/routes/ | 0.4KB | Shipping status management |
| returnRoutes.js | server/src/routes/ | 0.4KB | Return workflow |

### Controllers (23 files)
| File | Size | Key Functions |
|------|------|---------------|
| authController.js | 7.1KB | login, refresh, logout, getProfile, changePassword |
| reportController.js | 10.2KB | getRevenue, getProfit, getTopProducts, getInventory, getHRStats, 3x CSV exports |
| staffController.js | 6.0KB | getProfile, updateProfile, getMySalaries, getMyLeaves, createLeave, getDashboard |
| userController.js | 3.8KB | getAll, create, update, delete, toggleActive |
| promotionController.js | 3.5KB | getAll, getById, validateCode, create, update, delete |
| roleController.js | 3.7KB | getAll, getById, getPermissions, create, update, updatePermissions, delete |
| salaryController.js | 3.2KB | getAll, generate, update |
| returnController.js | 2.7KB | getAll, getById, create, approve, complete, reject |
| paymentController.js | 2.3KB | getAll, getByInvoice, confirm |
| settingController.js | 2.0KB | getAll, getByKey, upsert, bulkUpsert |
| leaveController.js | 1.9KB | getAll, getById, create, approve, reject, delete |
| productController.js | 1.9KB | getAll, getById, create, update, delete, getLowStock |
| employeeController.js | 1.8KB | getAll, getById, create, update, delete |
| customerController.js | 1.7KB | getAll, getById, create, update |
| shippingController.js | 1.7KB | getAll, getByInvoice, updateStatus |
| invoiceController.js | 1.4KB | getAll, getById, create, getRevenueStats, delete |
| notificationController.js | 1.4KB | getMyNotifications, markRead, markAllRead |
| reviewController.js | 1.4KB | getAll, getByProduct, create, toggleVisibility, delete |
| categoryController.js | 1.2KB | getAll, getById, getTree, create, update, delete |
| positionController.js | 1.2KB | getAll, getById, create, update, delete |
| supplierController.js | 1.2KB | getAll, getById, create, update, delete |
| importController.js | 1.2KB | getAll, getById, create, delete |
| brandController.js | 1.2KB | getAll, getById, create, update, delete |

### Middleware (4 files)
| File | Purpose |
|------|---------|
| authMiddleware.js | JWT verify, roleCheck, adminOnly, managerUp |
| validationMiddleware.js | express-validator for 10 routes |
| errorHandler.js | Global error middleware |
| uploadMiddleware.js | Multer for file uploads |

### Utils (7 files)
| File | Purpose |
|------|---------|
| generateToken.js | Access/refresh token generation, verification, revocation |
| loginThrottler.js | 5-attempt lockout with DB persistence |
| auditLogger.js | Audit trail writer |
| inventoryLogger.js | Stock movement tracker |
| settingsCache.js | In-memory 5-min TTL settings cache |
| salaryCalculation.js | Cross-month salary with leave overlap |
| helpers.js | Utility functions |

## Client Files

### Pages (14 admin + 4 staff)
| File | Size | Route |
|------|------|-------|
| HomePage.jsx | 12.5KB | /admin |
| ProductsPage.jsx | 12.1KB | /admin/products |
| InvoicesPage.jsx | 16.7KB | /admin/invoices |
| ImportsPage.jsx | 11.7KB | /admin/imports |
| ReportsPage.jsx | 11.9KB | /admin/reports |
| CustomersPage.jsx | 7.2KB | /admin/customers |
| EmployeesPage.jsx | 7.4KB | /admin/employees |
| SalariesPage.jsx | 8.0KB | /admin/salaries |
| UsersPage.jsx | 4.7KB | /admin/users |
| ReviewsPage.jsx | 3.0KB | /admin/reviews |
| LeavesPage.jsx | 2.8KB | /admin/leaves |
| BrandsPage.jsx | 1.0KB | /admin/brands |
| CategoriesPage.jsx | 0.7KB | /admin/categories |
| PositionsPage.jsx | 0.9KB | /admin/positions |
| SuppliersPage.jsx | 1.0KB | /admin/suppliers |
| LoginPage.jsx | - | /admin/login |
| NotFoundPage.jsx | - | * |

### Shop Components (7 files)
| File | Size | Route |
|------|------|-------|
| StorefrontHome.jsx | 9.9KB | /shop |
| ShopPage.jsx | 12.2KB | /shop/products |
| ProductDetailPage.jsx | 9.8KB | /shop/product/:id |
| CheckoutPage.jsx | 11.2KB | /shop/checkout |
| ShopAuthPage.jsx | 7.7KB | /shop/auth |
| CartPage.jsx | 4.8KB | /shop/cart |
| ShopLayout.jsx | 7.6KB | Layout wrapper |

### Services (6 files)
| File | Purpose |
|------|---------|
| api.js | Axios instance, interceptors, token injection |
| authService.js | login, getProfile, customerLogin, customerRegister |
| dataService.js | CRUD wrappers for all admin modules |
| publicService.js | Public shop API calls |
| staffService.js | Staff self-service API calls |
| exportService.js | CSV download helper |

## Database Files
| File | Purpose | Size |
|------|---------|------|
| schema.sql | Full schema (25 tables, 6 triggers, indexes) | 15.2KB |
| seed.sql | Demo data | - |
| migrations/ (21 files) | Sequential schema evolution | - |

# Architecture Verified

## Stack [CONFIRMED]
| Layer | Tech | Version | Evidence |
|-------|------|---------|----------|
| Frontend | React + Vite | 18.3 / 5.4 | `client/package.json:12-13` |
| Routing | react-router-dom | 6.26 | `client/package.json:16` |
| State | React Context API | - | `AuthContext.jsx`, `CartContext.jsx` |
| HTTP | Axios | 1.7.7 | `client/package.json:12` |
| Charts | Recharts | 3.8.1 | `client/package.json:18` |
| Backend | Express | 4.21 | `server/package.json:14` |
| DB | MySQL 8.0 | - | `database/schema.sql:3` |
| Driver | mysql2 | 3.11 | `server/package.json:20` |
| Auth | JWT + bcryptjs | 9.0.2 / 2.4.3 | `server/package.json:11,18` |
| Security | helmet + express-rate-limit | 8.1 / 8.3 | `server/package.json:16-17` |
| Validation | express-validator | 7.3 | `server/package.json:16` |
| Upload | multer | 1.4.5 | `server/package.json:19` |

## Request Pipeline [CONFIRMED]
```
Client → Helmet → CORS(multi-origin) → Rate Limiter → express.json(10mb) → [Auth Middleware if protected] → [Validation if defined] → Controller → Model → MySQL → Response
```
Evidence: `server.js:41-70` defines middleware order.

## Module Boundaries [CONFIRMED]

```
┌─────────────────────────────────────────────────────────┐
│ CLIENT (React SPA)                                       │
│ ┌───────────┐ ┌──────────┐ ┌──────────┐ ┌────────────┐ │
│ │ Admin UI  │ │ Staff UI │ │ Shop UI  │ │ Auth UI    │ │
│ │ (14 pages)│ │ (4 pages)│ │ (7 comps)│ │ (login/reg)│ │
│ └─────┬─────┘ └────┬─────┘ └────┬─────┘ └─────┬──────┘ │
│       │            │            │              │         │
│       └────────────┴────────────┴──────────────┘         │
│                         │ Axios (api.js)                  │
└─────────────────────────┼────────────────────────────────┘
                          │ HTTP/JSON
┌─────────────────────────┼────────────────────────────────┐
│ SERVER (Express)         │                                │
│ ┌────────┐ ┌──────────┐ ┌──────────┐ ┌───────────────┐  │
│ │25 Route│→│23 Control│→│23 Models │→│ MySQL (25 tbl) │  │
│ │ files  │ │  files   │ │ (raw SQL)│ │ + 6 triggers   │  │
│ └────────┘ └──────────┘ └──────────┘ └───────────────┘  │
│     ↕           ↕                                        │
│ ┌────────┐ ┌──────────┐                                  │
│ │4 M.ware│ │7 Utils   │                                  │
│ └────────┘ └──────────┘                                  │
└──────────────────────────────────────────────────────────┘
```

## Architecture Strengths [CONFIRMED]
1. **Clean MVC separation** — Routes only define endpoints and middleware chain. Controllers handle HTTP. Models handle SQL. No mixed concerns observed.
2. **Dual auth systems** — Staff (`authRoutes.js`) and Customer (`customerAuthRoutes.js`) completely isolated, different token generation, different tables. Correct.
3. **DB-driven business logic** — 6 triggers guarantee stock and CRM point consistency even if application code crashes mid-transaction. This is a deliberate (and correct) architecture choice.
4. **Code splitting** — `App.jsx:17-41` uses `React.lazy()` for all pages. Suspense fallback renders spinner.

## Architecture Weaknesses [CONFIRMED]
1. **No shared types** — No TypeScript, no DTO shared between client/server. Contract changes require manual sync.
2. **No service layer in backend** — Controllers call Models directly. Business logic lives in Models (e.g., `invoiceModel.create()` has 100+ lines of business logic). Should have a service layer between.
3. **Inconsistent error handling** — 13 controllers use `next(error)` (correct). 4 controllers (`roleController`, `promotionController`, `settingController`, `notificationController`) use `res.status(500).json({error: error.message})` (bypasses errorHandler, leaks internals).
4. **No caching** — No Redis, no CDN. Every request hits MySQL. Acceptable for thesis, bottleneck for >100 concurrent users.
5. **Cart is client-only** — `CartContext.jsx` uses localStorage. No server-side cart table. Lost on device switch.

## Anti-Patterns Found [CONFIRMED]
1. **God Model** — `invoiceModel.create()` (68-206, 138 lines) handles stock locking, discount calculation, promotion application, payment transaction creation, inventory logging, and item insertion. Should be decomposed.
2. **Mixed concerns in routes** — `publicRoutes.js` (279 lines) has inline query logic (featured, new-arrivals, related products) instead of delegating to controllers. This file should be considered a "fat route" anti-pattern.

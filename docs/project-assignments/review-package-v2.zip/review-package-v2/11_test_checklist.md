# Test Checklist

> Manual and automated test scenarios to verify system integrity.

## Critical Path Tests (Must Pass Before Deployment)

### T1: Invoice Create — Price Integrity
| Step | Action | Expected | Status |
|------|--------|----------|--------|
| 1 | Admin login → Invoices → Tạo hóa đơn | Form opens | |
| 2 | Search product, add to cart | Product appears with correct sell_price | |
| 3 | Open DevTools, intercept POST /api/invoices | See payload with `unit_price` | |
| 4 | Modify `unit_price` to 1 and resend | **Should be rejected or overridden by server** | **⚠️ WILL FAIL until Patch 1.2** |
| 5 | After Patch 1.2: Repeat step 4 | Server uses sell_price from DB, ignores client price | |

### T2: Invoice Delete → Soft Cancel
| Step | Action | Expected | Status |
|------|--------|----------|--------|
| 1 | Create an invoice with known product | Invoice created, stock reduced | |
| 2 | Delete/Cancel the invoice | **Should set status='cancelled', NOT delete row** | **⚠️ WILL FAIL until Patch 1.1** |
| 3 | After Patch 1.1: Verify stock restored | stock_quantity += item quantity | |
| 4 | Verify CRM points rolled back | customer.total_points -= points_earned | |
| 5 | Verify invoice still visible in list (as cancelled) | Status badge shows "Đã hủy" | |

### T3: Shop Checkout — Customer Linkage
| Step | Action | Expected | Status |
|------|--------|----------|--------|
| 1 | Register customer account at /shop/auth | Account created | |
| 2 | Login as customer | Token stored | |
| 3 | Add products to cart, proceed to checkout | Form auto-fills profile data | |
| 4 | Complete checkout | **Invoice should have customer_id set** | **⚠️ WILL FAIL until Patch 2.1** |
| 5 | After Patch 2.1: Check invoice in DB | customer_id = registered customer's ID | |
| 6 | Verify CRM points earned by customer | total_points increased | |

### T4: Inventory Consistency
| Step | Action | Expected | Status |
|------|--------|----------|--------|
| 1 | Note current stock_quantity for product X | e.g., 50 | |
| 2 | Create invoice with qty=3 | stock → 47 | |
| 3 | Create import with qty=10 | stock → 57 | |
| 4 | Cancel invoice (after Patch 1.1) | stock → 60 | |
| 5 | Check inventory_movements table | 3 entries: sale(-3), import(+10), cancellation(+3) | |

## Functional Tests

### T5: Auth Flow
| # | Test | Expected |
|---|------|----------|
| 5.1 | Login with correct credentials | Token returned, redirect to /admin |
| 5.2 | Login with wrong password 5 times | Account locked for 30 min |
| 5.3 | Login with locked account | 429 response with lockout message |
| 5.4 | Refresh token after access token expires | New access token issued |
| 5.5 | Change password | All other sessions invalidated |
| 5.6 | Access /api/invoices without token | 401 Unauthorized |
| 5.7 | Staff access /api/users | 403 Forbidden |

### T6: Role-Based Access
| # | Action | Admin | Manager | Staff | Warehouse |
|---|--------|-------|---------|-------|-----------|
| 6.1 | View products | ✅ | ✅ | ✅ | ✅ |
| 6.2 | Manage employees | ✅ | ✅ | ❌ | ❌ |
| 6.3 | Delete invoices | ✅ | ✅ | ❌ | ❌ |
| 6.4 | View reports | ✅ | ✅ | ❌ | ❌ |
| 6.5 | Manage imports | ✅ | ✅ | ❌ | ✅ |
| 6.6 | Manage users | ✅ | ❌ | ❌ | ❌ |
| 6.7 | View own salary | ✅ | ✅ | ✅ | ✅ |

### T7: Leave Management
| # | Test | Expected |
|---|------|----------|
| 7.1 | Staff creates leave request | Status = pending |
| 7.2 | Manager approves leave | Status = approved |
| 7.3 | Staff views own leave | Visible |
| 7.4 | Staff views other's leave | 403 Forbidden (IDOR check) |
| 7.5 | Create overlapping leave (same dates) | **Should be rejected** (after Patch 6.1) |

### T8: Salary Calculation
| # | Test | Expected |
|---|------|----------|
| 8.1 | Generate salary for employee with no leaves | net_salary = base_salary |
| 8.2 | Generate salary with 2 days unpaid leave | net_salary = base × (20/22) |
| 8.3 | Generate salary with annual leave | No deduction |
| 8.4 | Leave spans 2 months → generate for month 1 | Only overlap days counted |

### T9: Shop E2E
| # | Test | Expected |
|---|------|----------|
| 9.1 | Browse /shop → view featured products | Products with images and prices |
| 9.2 | Filter by category | Products filtered correctly |
| 9.3 | Add to cart → view cart | Cart shows items with totals |
| 9.4 | Clear browser → cart persists | localStorage preserves cart |
| 9.5 | Checkout without login | Redirect to login page |
| 9.6 | Checkout with login | Order created successfully |
| 9.7 | Check stock after purchase | Reduced by purchased quantity |

### T10: CSV Export
| # | Test | Expected |
|---|------|----------|
| 10.1 | Export invoices CSV | File downloads with Vietnamese headers, BOM for Excel |
| 10.2 | Export products CSV | All products listed with categories |
| 10.3 | Export customers CSV | Customer data with tier and total spent |

## API Regression Tests (cURL)

```bash
# Health check
curl http://localhost:5001/api/health

# Login
curl -X POST http://localhost:5001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}'

# Price manipulation test (should fail after patch)
TOKEN="<from login>"
curl -X POST http://localhost:5001/api/invoices \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"items":[{"product_id":1,"quantity":1,"unit_price":1}],"payment_method":"cash"}'

# Public checkout
curl -X POST http://localhost:5001/api/public/checkout \
  -H "Content-Type: application/json" \
  -d '{"items":[{"product_id":1,"quantity":1}],"customer_name":"Test","customer_phone":"0901234567","payment_method":"cod"}'
```

## Known Untestable Items
1. **Trigger behavior** — Cannot be unit tested from API. Requires DB-level verification.
2. **Email sending** — No email service configured. Cannot test email notifications.
3. **File upload** — Requires multipart form data. Not tested via simple cURL.
4. **Rate limiting** — Requires 20+ rapid requests. Not practical in manual testing.

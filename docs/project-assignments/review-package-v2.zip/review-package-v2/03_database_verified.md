# Database Verified

## Schema Summary [CONFIRMED]
- **Database:** `julie_cosmetics`, UTF8MB4, InnoDB
- **Total Tables:** 25 (in `schema.sql`) + 21 migrations
- **Triggers:** 6 active triggers

## Table Groups & Usage Status

### Group 1: HR (6 tables) — FULLY USED [CONFIRMED]
| Table | Used by Backend | Used by Frontend | Soft Delete | Notes |
|-------|----------------|-----------------|-------------|-------|
| `positions` | positionController, salaryCalculation | PositionsPage | No | Master data |
| `employees` | employeeController, staffController | EmployeesPage | Yes (`deleted_at`) | Core HR entity |
| `employee_positions` | salaryCalculation.js:13-18 | Staff profile | No | Position history |
| `leave_requests` | leaveController, staffController | LeavesPage, MyLeavePage | No | Hard delete |
| `salaries` | salaryController | SalariesPage, MySalaryPage | No | UNIQUE(emp,month,year) |
| `users` | authController, userController | UsersPage, LoginPage | Yes (`deleted_at`) | Auth accounts |

### Group 2: Inventory (6 tables) — FULLY USED [CONFIRMED]
| Table | Used by Backend | Used by Frontend | Soft Delete | Notes |
|-------|----------------|-----------------|-------------|-------|
| `products` | productController, publicRoutes | ProductsPage, ShopPage | Yes | FULLTEXT index |
| `categories` | categoryController, publicRoutes | CategoriesPage | No | Self-referential parent_id |
| `brands` | brandController, publicRoutes | BrandsPage | Yes (`deleted_at`) | |
| `suppliers` | supplierController | SuppliersPage | Yes (`deleted_at`) | |
| `import_receipts` | importController | ImportsPage | No | Hard delete |
| `import_receipt_items` | importModel.create | ImportsPage detail | No | CASCADE from receipt |

### Group 3: Sales/CRM (4 tables) — FULLY USED [CONFIRMED]
| Table | Used by Backend | Used by Frontend | Notes |
|-------|----------------|-----------------|-------|
| `customers` | customerController, customerAuthRoutes | CustomersPage, ShopAuth | Has password_hash for e-commerce |
| `invoices` | invoiceController, reportController | InvoicesPage | Has `status` column but app uses hard delete |
| `invoice_items` | invoiceModel.create | Invoice detail view | CASCADE from invoice |
| `reviews` | reviewController, publicRoutes | ReviewsPage, product detail | UNIQUE(customer_id, product_id) |

### Group 4: Audit (2 tables) — PARTIALLY USED [CONFIRMED]
| Table | Used by Backend | Used by Frontend | Status |
|-------|----------------|-----------------|--------|
| `audit_logs` | `auditLogger.js` → called from authController, returnController | **No FE page** | Written to but never displayed. No admin UI to view audit logs. |
| `inventory_movements` | `inventoryLogger.js` → called from invoiceModel, importModel, returnModel | **No FE page** | Written to but never displayed. |

### Group 5: RBAC (3 tables) — DEAD SCHEMA [CONFIRMED]
| Table | Used by Backend | Used by Frontend | Status |
|-------|----------------|-----------------|--------|
| `roles` | roleController — CRUD exists | **No FE page** | API works but sidebar has no nav item |
| `permissions` | roleController — query exists | **No FE page** | Middleware doesn't check this table |
| `role_permissions` | roleController — manage exists | **No FE page** | Junction table, never queried for auth |

### Group 6: E-commerce Extensions (6 tables) — PARTIALLY USED
| Table | Used by Backend | Used by Frontend | Status |
|-------|----------------|-----------------|--------|
| `product_images` | productImageModel, publicRoutes | Product detail page | [CONFIRMED] Working |
| `skin_types` | **Not queried** | **Not used** | [CONFIRMED] Dead table |
| `product_skin_types` | **Not queried** | **Not used** | [CONFIRMED] Dead table |
| `promotions` | promotionController | **No admin page** | [CONFIRMED] API works, no UI |
| `notifications` | notificationController | **No page** | [CONFIRMED] Dead — never triggered |
| `settings` | settingsCache.js, settingController | **No admin page** | [CONFIRMED] Used server-side only |

### Group 7: E-commerce Workflows (5 tables) — BACKEND ONLY
| Table | Used by Backend | Used by Frontend | Status |
|-------|----------------|-----------------|--------|
| `payment_transactions` | invoiceModel.create:174-178 | **No page** | [CONFIRMED] Written on invoice create, not displayed |
| `customer_addresses` | addressModel — via customerAuthRoutes | ShopAuthPage (profile) | [CONFIRMED] Working |
| `shipping_orders` | shippingModel — via publicRoutes checkout | **No tracking page** | [CONFIRMED] Created on checkout, not viewable |
| `returns` | returnController | **No admin page** | [CONFIRMED] API works, no sidebar nav |
| `return_items` | returnModel | **No admin page** | [CONFIRMED] Same as above |

### Group 8: Security (2 tables) — FULLY USED [CONFIRMED]
| Table | Used by Backend | Notes |
|-------|----------------|-------|
| `refresh_tokens` | generateToken.js | SHA-256 hashed, per-device, revoke-all support |
| `login_attempts` | loginThrottler.js | 5 attempts / 15 min window, 30 min lockout |

## Trigger Integrity [CONFIRMED]

| Trigger | On | Action | Verified |
|---------|------------|--------|----------|
| `trg_invoice_item_insert` | AFTER INSERT invoice_items | stock -= quantity | ✅ schema.sql:560-567 |
| `trg_invoice_item_delete` | BEFORE DELETE invoice_items | stock += quantity | ✅ schema.sql:570-577 |
| `trg_import_item_insert` | AFTER INSERT import_receipt_items | stock += quantity | ✅ schema.sql:580-587 |
| `trg_import_item_delete` | BEFORE DELETE import_receipt_items | stock -= quantity | ✅ schema.sql:590-597 |
| `trg_invoice_after_insert` | AFTER INSERT invoices | CRM points + tier upgrade | ✅ schema.sql:600-615 |
| `trg_invoice_before_delete` | BEFORE DELETE invoices | CRM points rollback + tier downgrade | ✅ schema.sql:618-633 |

## Index Coverage [CONFIRMED]
- All FK columns have indexes
- FULLTEXT on `products(product_name, description)` — supports LIKE search
- Composite indexes on frequently queried patterns: `(employee_id, end_date)`, `(employee_id, status)`, `(year, month)`

## Key Risks
1. **No `CHECK(stock_quantity >= 0)`** — DB allows negative stock if app-level validation fails. [CONFIRMED]
2. **Hard delete on invoices** — Despite having `status` column, deletion cascades to items and triggers rollback. No audit trail preserved. [CONFIRMED]
3. **8 dead or underused tables** — `skin_types`, `product_skin_types`, `notifications`, `promotions`, `roles`, `permissions`, `role_permissions`, `payment_transactions` (viewable). Significant schema-code gap. [CONFIRMED]

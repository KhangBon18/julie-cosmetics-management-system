# Report.docx Cross-Verification

> This document verifies every claim from the original `Report.docx` against actual source code.

## Claim: "unit_price từ FE client được ghi thẳng vào invoice_items — không validate với giá DB"
**Status: CONFIRMED — BUT NUANCED**

- **Admin POS path** (`InvoicesPage.jsx → invoiceController.create → invoiceModel.create`): **TRUE**. FE sends `unit_price` (line 113), server uses it directly at `invoiceModel.js:100`. Price manipulation possible via API call.
- **Public checkout path** (`CheckoutPage.jsx → publicRoutes.js /checkout`): **FALSE — FIXED**. At `publicRoutes.js:157-175`, server fetches `product.sell_price` from DB and builds `invoiceItems` with `unit_price: product.sell_price`. Client-sent price is ignored.

**Verdict**: Report claim partially correct. Public shop is safe. Admin POS is vulnerable.

---

## Claim: "Hard delete hóa đơn tài chính"
**Status: CONFIRMED — EXACT MATCH**

- `invoiceModel.js:235`: `await connection.query('DELETE FROM invoices WHERE invoice_id = ?', [id])`
- Route at `invoiceRoutes.js:11`: `router.delete('/:id', managerUp, invoiceController.delete)`
- Report correctly notes cascade to `invoice_items` → triggers fire to restore stock
- Report correctly notes CRM points NOT rolled back (trigger `trg_invoice_before_delete` does rollback `total_points` and `total_spent`)

**Additional finding**: Actually, `schema.sql:618-633` shows `trg_invoice_before_delete` DOES rollback CRM points. Report claim about CRM not rolling back is **INCORRECT for the current schema.sql**. The trigger handles it.

---

## Claim: "Notification system — hoàn toàn trống rỗng không được trigger"
**Status: CONFIRMED — EXACT MATCH**

- `grep -r "Notification.create" server/src/controllers/` → **0 results**
- Model, controller, routes exist but create() is never called by any business logic.

---

## Claim: "Promotion/Coupon KHÔNG dùng được ở Shop Checkout"
**Status: CONFIRMED — EXACT MATCH**

- `grep "promotion\|coupon\|discount" client/src/components/shop/CheckoutPage.jsx` → **0 results**
- Backend `publicRoutes.js:143-153` supports `promotion_code` — confirmed present.
- `publicService.js` has no `validatePromotion()` method — confirmed absent.

---

## Claim: "publicRoutes.js checkout → customer_id: null hardcode"
**Status: CONFIRMED — EXACT MATCH**

- `publicRoutes.js:178-179`: `await Invoice.create({ customer_id: null, ... })`
- Even if customer has authenticated via `customer-auth`, their ID is not extracted from request context.
- `CheckoutPage.jsx:57-60` does NOT send `customer_id` in the checkout payload.

---

## Claim: "generateToken.js xuất sắc — access token 15 phút, refresh token 30 ngày lưu hash SHA-256"
**Status: CONFIRMED — EXACT MATCH**

- `generateToken.js:10`: `expiresIn: '15m'`
- `generateToken.js:20`: `crypto.createHash('sha256').update(rawToken).digest('hex')`
- `generateToken.js:21`: 30 days expiry math confirmed
- Revoke per-device: `revokeRefreshToken()` line 58
- Revoke all: `revokeAllUserTokens()` line 69

---

## Claim: "SettingsCache.js tốt — in-memory cache 5 phút"
**Status: CONFIRMED — EXACT MATCH**

- `settingsCache.js:6`: `const CACHE_TTL_MS = 5 * 60 * 1000`
- `settingsCache.js:22`: `castValue()` handles number, boolean, json types
- `settingsCache.js:46-48`: `invalidate()` clears cache
- **Used by**: `invoiceModel.create()` line 104 — correctly reads CRM discount and points settings.

---

## Claim: "productModel.findAll() xử lý category filter thông minh — include cả children"
**Status: CONFIRMED — EXACT MATCH**

- `productModel.js:26`: `AND (p.category_id = ? OR c.parent_id = ?)`
- Passes `category_id` twice to cover both exact match and parent match.

---

## Claim: "leaveController.getById() có kiểm tra IDOR"
**Status: CONFIRMED — EXACT MATCH**

- `leaveController.js:17-19`: `if (role !== 'admin' && role !== 'manager' && item.employee_id !== req.user.employee_id) return 403`
- Correct IDOR prevention for staff viewing others' leave requests.

---

## Claim: "staffController.updateProfile() chỉ cho phép update phone và address"
**Status: CONFIRMED — EXACT MATCH**

- `staffController.js:29`: `const { phone, address } = req.body` — destructures only 2 fields.
- Cannot modify salary, position, status, or other sensitive fields.

---

## Claim: "Error handling không nhất quán — 20 chỗ dùng res.status(500)"
**Status: CONFIRMED — EXACT COUNT: 19 instances**

Found in: `roleController.js` (7), `promotionController.js` (5), `settingController.js` (4), `notificationController.js` (3).
All bypass `errorHandler.js` middleware and expose `error.message` to client.

---

## Claim: "Leave model thiếu total_days auto-calculate — leaveController.create() dùng req.body"
**Status: CONFIRMED — EXACT MATCH**

- `leaveController.js:26-28`: `const id = await Leave.create(req.body)` — raw body including `total_days`
- `staffController.js:104-107`: Correctly calculates `Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1`
- Admin/manager path trusts client input. Staff path auto-calculates. Inconsistent.

---

## Claim: "salaryCalculation.js xử lý cross-month leave đúng cách bằng LEAST/GREATEST"
**Status: CONFIRMED — EXACT MATCH**

- `salaryCalculation.js:26-36`: Uses `LEAST(end_date, LAST_DAY(...))` and `GREATEST(start_date, CONCAT(year, month, '01'))` to calculate only the overlap days within the target month.
- This is a non-trivial SQL pattern that handles leaves spanning multiple months correctly.

---

## Claim: "ORDER BY RAND() ở related products"
**Status: CONFIRMED — EXACT MATCH**

- `publicRoutes.js:118`: `ORDER BY RAND() LIMIT ?`
- Performance concern is valid for large product tables (>10K rows) but acceptable for current scale.

---

## Claims NOT in Report.docx (NEW FINDINGS)

1. **Return items not validated against source invoice** — returnController.create() accepts any product_id, doesn't verify it exists in the referenced invoice. [NEW]
2. **Leave overlap not checked** — Both leave create paths allow overlapping date ranges for same employee. [NEW]
3. **Audit logging inconsistent** — Only auth + return modules use `logAudit()`. Major operations (invoice, import, employee) don't. [NEW]
4. **Product.update() does NOT include stock_quantity** — Report.docx implied stock could be overwritten via update. This is INCORRECT in current code. Cleared. [CLEARED]
5. **FE discount % hardcoded** — `InvoicesPage.jsx:60-63` hardcodes gold=5%, silver=2%. Server uses dynamic settings. [NEW]
6. **Shipping fee hardcoded in FE** — `CheckoutPage.jsx:39` uses 500K threshold. Not validated server-side. [NEW]
7. **FE logout doesn't revoke server token** — `AuthContext.jsx:64-67` only clears localStorage. Refresh token remains valid in DB for 30 days. [NEW]
